def handler(event, context):
    return {
        'statusCode': 200,
        'body': 'Bonjour de la part d Infoline 2026 !'
    }
